package com.example.puzzlecracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.io.IOException;
import java.lang.*;
import android.app.Activity;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Vector;


public class HomeActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

   /////////////////////////////////////////////////////////////////////////////
   public String answer;
    public void permute(int[] a, int k)
    {
        if (k == N&&check(a))
        {
            // diff combination
            display(a);
        }
        else
        {
            for (int i = k; i < a.length; i++)
            {
                int temp = a[k];
                a[k] = a[i];
                a[i] = temp;

                permute(a, k + 1);

                temp = a[k];
                a[k] = a[i];
                a[i] = temp;
            }
        }
    }

    public void display(int[]ans)
    {
        String temp="";
        for(int i=0;i<N;i++)
        {
            temp=temp+Integer.toString(ans[i]);
        }
        answer= temp;  // trick
    }

    int N=3,n=5;// clue digits,clue nos
    public boolean overlap(int[] ar1,int ar[],int nn)
    {
        for(int i=0;i<N;i++)
        {
            for(int j=0;j<N;j++)
                if(ar1[i]==ar[j])
                    nn--;
        }
        if(nn==0)
            return true;
        else
            return false;
    }

    public boolean index(int[] ar1,int ar[],int nn)
    {
        for(int i=0;i<N;i++)
        {
            for(int j=0;j<N;j++)
                if(ar1[i]==ar[j]&&i==j)
                    nn--;
        }
        if(nn==0)
            return true;
        else
            return false;
    }



    int[][] ls=new int[n][N+1];
    public boolean check(int ar1[])
    {
        for(int i=0;i<n;i++) // no of clues
        {
            int[] ar2= new int[N];
            ar2=ls[i];

            int ch=ls[i][N];
            switch(ch)
            {
                case 1:{
                    if(!overlap(ar1,ar2,0))
                        return false;
                    else
                        break;
                }
                case 2:{
                    if(!(overlap(ar1,ar2,1)&&index(ar1,ar2,0)))
                        return false;
                    else
                        break;
                }
                case 3:{
                    if(!(overlap(ar1,ar2,1)&&index(ar1,ar2,1)))
                        return false;
                    else
                        break;
                }
                case 4:{
                    if(!(overlap(ar1,ar2,2)&&index(ar1,ar2,0)))
                        return false;
                    else
                        break;
                }
                case 5:{
                    if(!(overlap(ar1,ar2,2)&&index(ar1,ar2,2)))
                        return false;
                    else
                        break;
                }
                default:{
                    System.out.println("error happened");
                    break;
                }
            }
        }
        return true;
    }

    ////////////////////////////////////////////////////////////////////////////
    EditText c1_1, c1_2, c1_3;
    EditText c2_1, c2_2, c2_3;
    EditText c3_1, c3_2, c3_3;
    EditText c4_1, c4_2, c4_3;
    EditText c5_1, c5_2, c5_3;
    protected static   String tempp;
    private static int[][] clue = new int[5][4];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        c1_1 = findViewById(R.id.c1_1);
        c1_2 = findViewById(R.id.c1_2);
        c1_3 = findViewById(R.id.c1_3);
        c2_1 = findViewById(R.id.c2_1);
        c2_2 = findViewById(R.id.c2_2);
        c2_3 = findViewById(R.id.c2_3);
        c3_1 = findViewById(R.id.c3_1);
        c3_2 = findViewById(R.id.c3_2);
        c3_3 = findViewById(R.id.c3_3);
        c4_1 = findViewById(R.id.c4_1);
        c4_2 = findViewById(R.id.c4_2);
        c4_3 = findViewById(R.id.c4_3);
        c5_1 = findViewById(R.id.c5_1);
        c5_2 = findViewById(R.id.c5_2);
        c5_3 = findViewById(R.id.c5_3);

        final Spinner spinner1 = findViewById(R.id.spinner1);
        final Spinner spinner2 = findViewById(R.id.spinner2);
        final Spinner spinner3 = findViewById(R.id.spinner3);
        final Spinner spinner4 = findViewById(R.id.spinner4);
        final Spinner spinner5 = findViewById(R.id.spinner5);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.numbers, android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);
        spinner1.setOnItemSelectedListener(this);
        spinner2.setAdapter(adapter);
        spinner2.setOnItemSelectedListener(this);
        spinner3.setAdapter(adapter);
        spinner3.setOnItemSelectedListener(this);
        spinner4.setAdapter(adapter);
        spinner4.setOnItemSelectedListener(this);
        spinner5.setAdapter(adapter);
        spinner5.setOnItemSelectedListener(this);

        Button b = findViewById(R.id.solve);
        b.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                
                clue[0][3] = spinner1.getSelectedItemPosition() + 1;
                clue[1][3] = spinner2.getSelectedItemPosition() + 1;
                clue[2][3] = spinner3.getSelectedItemPosition() + 1;
                clue[3][3] = spinner4.getSelectedItemPosition() + 1;
                clue[4][3] = spinner5.getSelectedItemPosition() + 1;

                clue[0][0] = Integer.parseInt(c1_1.getText().toString());
                clue[0][1] = Integer.parseInt(c1_2.getText().toString());
                clue[0][2] = Integer.parseInt(c1_3.getText().toString());
                clue[1][0] = Integer.parseInt(c2_1.getText().toString());
                clue[1][1] = Integer.parseInt(c2_2.getText().toString());
                clue[1][2] = Integer.parseInt(c2_3.getText().toString());
                clue[2][0] = Integer.parseInt(c3_1.getText().toString());
                clue[2][1] = Integer.parseInt(c3_2.getText().toString());
                clue[2][2] = Integer.parseInt(c3_3.getText().toString());
                clue[3][0] = Integer.parseInt(c4_1.getText().toString());
                clue[3][1] = Integer.parseInt(c4_2.getText().toString());
                clue[3][2] = Integer.parseInt(c4_3.getText().toString());
                    clue[4][0] = Integer.parseInt(c5_1.getText().toString());
                    clue[4][1] = Integer.parseInt(c5_2.getText().toString());
                    clue[4][2] = Integer.parseInt(c5_3.getText().toString());


              ///////////////////////////////////////////////////////////////
                int[] number=new int[10];

                for(int i=0;i<10;i++)
                    number[i]=i;

                ls=clue;
                permute(number,0);
                tempp=answer;
               //////////////////////////////////////////////////////////////
              startActivity(new Intent(HomeActivity.this,Pop.class));
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
        //    String text = parent.getItemAtPosition(position).toString();
        //    num=position+1;
        //    System.out.println(num);
        //    Toast.makeText(parent.getContent(),text,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}