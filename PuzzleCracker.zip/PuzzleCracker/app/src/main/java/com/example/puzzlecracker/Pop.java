package com.example.puzzlecracker;

import android.os.Bundle;
import android.app.Activity;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

class another extends HomeActivity
{
    String w=this.tempp;
}

public class Pop extends Activity {

    public int ans;

    TextView answer;
    public void onCreate(Bundle savedInstanceState)
    {
        final another obj=new another();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.popupwindow);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int height =dm.heightPixels;
        answer=findViewById(R.id.answer);
        answer.setText(String.valueOf(obj.w));
        getWindow().setLayout((int)(width*.8),(int)(height*.6));


        };
    }

